package com.sketchbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.net.Uri

object Tracer {

    class Result(val phases: List<Phase>, val w: Int, val h: Int, val preview: Bitmap)

    // ---------- تحميل الصورة + قص الهوامش ----------
    class Loaded(
        val bmp: Bitmap,
        val fx0: Float, val fy0: Float, val fw: Float, val fh: Float,
        val aspect: Float
    )

    fun load(ctx: Context, uri: Uri, maxSide: Int): Loaded? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (Math.max(o.outWidth, o.outHeight) / s > 2600) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val full = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, o2)
        } ?: return null

        val fwPx = full.width
        val fhPx = full.height
        val box = contentBox(full)
        var x0 = 0
        var y0 = 0
        var x1 = fwPx - 1
        var y1 = fhPx - 1
        if (box != null) { x0 = box[0]; y0 = box[1]; x1 = box[2]; y1 = box[3] }
        val cropped = Bitmap.createBitmap(full, x0, y0, x1 - x0 + 1, y1 - y0 + 1)

        val k = maxSide.toFloat() / Math.max(cropped.width, cropped.height)
        val bmp = if (k < 1f) Bitmap.createScaledBitmap(
            cropped,
            Math.max(1, (cropped.width * k).toInt()),
            Math.max(1, (cropped.height * k).toInt()),
            true
        ) else cropped

        return Loaded(
            bmp,
            x0.toFloat() / fwPx, y0.toFloat() / fhPx,
            (x1 - x0 + 1).toFloat() / fwPx, (y1 - y0 + 1).toFloat() / fhPx,
            fwPx.toFloat() / fhPx
        )
    }

    private fun contentBox(src: Bitmap): IntArray? {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                if (Color.alpha(c) < 128) continue
                if (Color.red(c) < 240 || Color.green(c) < 240 || Color.blue(c) < 240) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return null
        val pad = 16
        return intArrayOf(
            Math.max(0, minX - pad), Math.max(0, minY - pad),
            Math.min(w - 1, maxX + pad), Math.min(h - 1, maxY + pad)
        )
    }

    private fun grad(c: IntArray, i: Int, w: Int): Int {
        val gx = -c[i - w - 1] + c[i - w + 1] - 2 * c[i - 1] + 2 * c[i + 1] - c[i + w - 1] + c[i + w + 1]
        val gy = -c[i - w - 1] - 2 * c[i - w] - c[i - w + 1] + c[i + w - 1] + 2 * c[i + w] + c[i + w + 1]
        return Math.abs(gx) + Math.abs(gy)
    }

    private fun morph(src: BooleanArray, w: Int, h: Int, r: Int, erode: Boolean): BooleanArray {
        val tmp = BooleanArray(w * h)
        val out = BooleanArray(w * h)
        val pre = IntArray(Math.max(w, h) + 1)
        val full = 2 * r + 1
        for (y in 0 until h) {
            pre[0] = 0
            for (x in 0 until w) pre[x + 1] = pre[x] + (if (src[y * w + x]) 1 else 0)
            for (x in 0 until w) {
                val a = Math.max(0, x - r)
                val b = Math.min(w - 1, x + r)
                val c = pre[b + 1] - pre[a]
                tmp[y * w + x] = if (erode) c == full else c > 0
            }
        }
        for (x in 0 until w) {
            pre[0] = 0
            for (y in 0 until h) pre[y + 1] = pre[y] + (if (tmp[y * w + x]) 1 else 0)
            for (y in 0 until h) {
                val a = Math.max(0, y - r)
                val b = Math.min(h - 1, y + r)
                val c = pre[b + 1] - pre[a]
                out[y * w + x] = if (erode) c == full else c > 0
            }
        }
        return out
    }

    /**
     * threshold : حد السواد لخطوط الحدود
     * detail    : 0 = حدود سوداء فقط، وكلما زاد ظهرت خطوط التفاصيل الدقيقة
     * fillGap   : المسافة بين خطوط التلوين (حسب سمك فرشاتك)
     * colors    : عدد الألوان، و0 = رسم خطوط فقط بلا تلوين
     */
    fun process(src: Bitmap, threshold: Int, detail: Int, fillGap: Int, colors: Int, fill: Boolean = true): Result {
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val rr = IntArray(n)
        val gg = IntArray(n)
        val bb = IntArray(n)
        val lum = IntArray(n)
        for (i in 0 until n) {
            val c = px[i]
            if (Color.alpha(c) < 128) {
                rr[i] = 255; gg[i] = 255; bb[i] = 255; lum[i] = 255
            } else {
                rr[i] = Color.red(c); gg[i] = Color.green(c); bb[i] = Color.blue(c)
                lum[i] = (0.299 * rr[i] + 0.587 * gg[i] + 0.114 * bb[i]).toInt()
            }
        }

        val dark = BooleanArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            dark[i] = lum[i] < threshold
        }

        // مساحات داكنة سميكة (عيون، ظلال كبيرة)
        val rad0 = Math.max(5, Math.max(w, h) / 130)
        val thick = morph(dark, w, h, rad0, true)
        val opened = morph(thick, w, h, rad0, false)
        val region = BooleanArray(n)
        val lineDark = BooleanArray(n)
        for (i in 0 until n) {
            region[i] = opened[i] && dark[i]
            lineDark[i] = dark[i] && !region[i]
        }

        // ---------- الخطوط ----------
        val mask = if (colors > 0) BooleanArray(n) else lineDark.copyOf()
        if (detail > 0) {
            val t = Math.max(15, 115 - detail)
            val rad = 4
            for (y in rad until h - rad) {
                for (x in rad until w - rad) {
                    val i = y * w + x
                    if (dark[i]) continue
                    val m = Math.max(grad(rr, i, w), Math.max(grad(gg, i, w), grad(bb, i, w))) / 4
                    if (m <= t) continue
                    var near = false
                    var yy = -rad
                    while (yy <= rad && !near) {
                        var xx = -rad
                        while (xx <= rad) {
                            if (dark[i + yy * w + xx]) { near = true; break }
                            xx++
                        }
                        yy++
                    }
                    if (!near) mask[i] = true
                }
            }
        }
        thin(mask, w, h)
        val outline = ArrayList<List<PointF>>()
        outline.addAll(trace(mask, w, h))

        // لون الخطوط = متوسط ألوان البكسلات الداكنة
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var sc = 0L
        for (i in 0 until n) if (lineDark[i]) { sr += rr[i]; sg += gg[i]; sb += bb[i]; sc++ }
        val outColor = if (sc > 200) Color.rgb((sr / sc).toInt(), (sg / sc).toInt(), (sb / sc).toInt())
        else Color.rgb(30, 30, 30)

        val gap = Math.max(1, fillGap)
        val phases = ArrayList<Phase>()
        var labels: IntArray? = null
        var dFill: List<List<PointF>> = emptyList()
        var centers = IntArray(0)

        if (colors > 0) {
            // ---------- التلوين ----------
            val bg = background(rr, gg, bb, w, h)
            val valid = BooleanArray(n) { !bg[it] && !lineDark[it] }
            val q = mergeClose(quantize(rr, gg, bb, valid, colors), n, 34)
            var lb = q.labels
            val k = q.centers.size
            lb = smooth(lb, w, h, k)
            lb = smooth(lb, w, h, k)
            spread(lb, bg, w, h)
            labels = lb
            centers = q.centers
            // الخطوط الداكنة السميكة تُملأ كمنطقة لون مستقلة (تُرسم أخيراً فوق الألوان)
            val dl = IntArray(n) { if (lineDark[it]) 0 else -1 }
            dFill = scribble(dl, 0, w, h, gap)

            if (fill) {
                // ---------- وضع Fill: حدود كل منطقة + نقطة ضغط بأداة التعبئة ----------
                val minArea = Math.max(40, n / 15000)
                lb = cleanSmall(lb, w, h, k, minArea)
                labels = lb
                val plan = fillPlan(lb, w, h, k, gap)
                val area = IntArray(k)
                for (i in 0 until n) if (lb[i] >= 0) area[lb[i]]++
                val order = (0 until k).filter { plan.strokes[it].isNotEmpty() || plan.seeds[it].isNotEmpty() }
                    .sortedByDescending { area[it] }
                for ((idx, c) in order.withIndex()) {
                    val sd = plan.seeds[c]
                    val px = if (sd.isNotEmpty()) sd[0].x else -1f
                    val py = if (sd.isNotEmpty()) sd[0].y else -1f
                    phases.add(
                        Phase(centers[c], "لون ${idx + 1} من ${order.size}", plan.strokes[c], true, px, py, ArrayList(sd))
                    )
                }
            } else {
            val area = IntArray(k)
            for (i in 0 until n) if (lb[i] >= 0) area[lb[i]]++
            val order = (0 until k).sortedByDescending { area[it] }
            val parts = ArrayList<Triple<Int, List<List<PointF>>, PointF>>()
            for (c in order) {
                if (area[c] < 40) continue
                val fill2 = scribble(lb, c, w, h, gap)
                if (fill2.isNotEmpty()) parts.add(Triple(centers[c], fill2, pickPoint(lb, c, w, h)))
            }
            for ((idx, p) in parts.withIndex()) {
                phases.add(Phase(p.first, "لون ${idx + 1} من ${parts.size}", p.second, true, p.third.x, p.third.y))
            }
            }
        } else {
            outline.addAll(hatch(region, w, h, gap))
        }
        var op = PointF(-1f, -1f)
        for (st in outline) {
            if (st.size >= 15) {
                val mid = st[st.size / 2]
                val xi = mid.x.toInt()
                val yi = mid.y.toInt()
                if (xi in 0 until w && yi in 0 until h && lineDark[yi * w + xi]) { op = PointF(mid.x, mid.y); break }
            }
        }
        if (op.x < 0f) {
            for (i in 0 until n) if (lineDark[i]) { op = PointF(i % w + 0.5f, i / w + 0.5f); break }
        }
        val outStrokes = ArrayList<List<PointF>>()
        outStrokes.addAll(dFill)
        outStrokes.addAll(outline)
        phases.add(Phase(outColor, "الخطوط الخارجية", outStrokes, false, op.x, op.y))

        // ---------- المعاينة ----------
        val prev = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val fl = labels
        if (fl != null) {
            val img = IntArray(n)
            for (i in 0 until n) {
                val l = fl[i]
                img[i] = if (lineDark[i]) outColor else if (l >= 0) (0xFF000000.toInt() or centers[l]) else Color.WHITE
            }
            prev.setPixels(img, 0, w, 0, 0, w, h)
        } else {
            prev.eraseColor(Color.WHITE)
        }
        val cv = Canvas(prev)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (fl != null) outColor else Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
        }
        for (st in outline) {
            if (st.size < 2) continue
            val p = Path()
            p.moveTo(st[0].x, st[0].y)
            for (k2 in 1 until st.size) p.lineTo(st[k2].x, st[k2].y)
            cv.drawPath(p, paint)
        }
        return Result(phases, w, h, prev)
    }


    // ---------- مناطق متصلة بنفس اللون ----------
    private class Comps(val id: IntArray, val label: IntArray, val area: IntArray)

    private fun components(lb: IntArray, w: Int, h: Int): Comps {
        val n = w * h
        val id = IntArray(n) { -1 }
        val q = IntArray(n)
        val labs = ArrayList<Int>()
        val areas = ArrayList<Int>()
        for (s in 0 until n) {
            if (lb[s] < 0 || id[s] >= 0) continue
            val c = labs.size
            val l = lb[s]
            var head = 0
            var tail = 0
            q[tail++] = s
            id[s] = c
            while (head < tail) {
                val i = q[head++]
                val x = i % w
                val y = i / w
                if (x > 0 && id[i - 1] < 0 && lb[i - 1] == l) { id[i - 1] = c; q[tail++] = i - 1 }
                if (x < w - 1 && id[i + 1] < 0 && lb[i + 1] == l) { id[i + 1] = c; q[tail++] = i + 1 }
                if (y > 0 && id[i - w] < 0 && lb[i - w] == l) { id[i - w] = c; q[tail++] = i - w }
                if (y < h - 1 && id[i + w] < 0 && lb[i + w] == l) { id[i + w] = c; q[tail++] = i + w }
            }
            labs.add(l)
            areas.add(tail)
        }
        return Comps(id, labs.toIntArray(), areas.toIntArray())
    }

    // دمج المناطق الصغيرة جداً في أكثر جار لها حتى لا تبقى بقع بيضاء أو حدود كثيرة
    private fun cleanSmall(lb: IntArray, w: Int, h: Int, k: Int, minArea: Int): IntArray {
        val cp = components(lb, w, h)
        val n = w * h
        val votes = HashMap<Int, IntArray>()
        for (i in 0 until n) {
            val c = cp.id[i]
            if (c < 0 || cp.area[c] >= minArea) continue
            val v = votes.getOrPut(c) { IntArray(k) }
            val x = i % w
            val y = i / w
            if (x > 0 && lb[i - 1] >= 0 && lb[i - 1] != lb[i]) v[lb[i - 1]]++
            if (x < w - 1 && lb[i + 1] >= 0 && lb[i + 1] != lb[i]) v[lb[i + 1]]++
            if (y > 0 && lb[i - w] >= 0 && lb[i - w] != lb[i]) v[lb[i - w]]++
            if (y < h - 1 && lb[i + w] >= 0 && lb[i + w] != lb[i]) v[lb[i + w]]++
        }
        val target = HashMap<Int, Int>()
        for ((c, v) in votes) {
            var b = -1
            var bc = 0
            for (l in 0 until k) if (v[l] > bc) { bc = v[l]; b = l }
            target[c] = b
        }
        val out = lb.copyOf()
        for (i in 0 until n) {
            val c = cp.id[i]
            if (c < 0) continue
            val t = target[c]
            if (t != null) out[i] = t
        }
        return out
    }

    private class FillPlan(
        val strokes: Array<ArrayList<List<PointF>>>,
        val seeds: Array<ArrayList<PointF>>
    )

    /**
     * لكل منطقة: حلقات الحدود (تُرسم بلون المنطقة فتصبح مغلقة) + نقطة في أعمق مكان داخلها
     * ليضغط عندها البوت بأداة Fill. المناطق الرفيعة التي تغطيها الفرشاة نفسها لا تحتاج ضغطة.
     */
    private fun fillPlan(lb: IntArray, w: Int, h: Int, k: Int, gap: Int): FillPlan {
        val n = w * h
        val cp = components(lb, w, h)
        val id = cp.id
        val bd = BooleanArray(n)
        val dist = IntArray(n) { -1 }
        val q = IntArray(n)
        var tail = 0
        for (i in 0 until n) {
            val c = id[i]
            if (c < 0) continue
            val x = i % w
            val y = i / w
            val edge = x == 0 || y == 0 || x == w - 1 || y == h - 1 ||
                id[i - 1] != c || id[i + 1] != c || id[i - w] != c || id[i + w] != c
            if (edge) { bd[i] = true; dist[i] = 0; q[tail++] = i }
        }
        val cn = cp.area.size
        val best = IntArray(cn) { -1 }
        val seedPix = IntArray(cn) { -1 }
        var head = 0
        while (head < tail) {
            val i = q[head++]
            val c = id[i]
            val d = dist[i]
            if (d > best[c]) { best[c] = d; seedPix[c] = i }
            val x = i % w
            val y = i / w
            if (x > 0 && id[i - 1] == c && dist[i - 1] < 0) { dist[i - 1] = d + 1; q[tail++] = i - 1 }
            if (x < w - 1 && id[i + 1] == c && dist[i + 1] < 0) { dist[i + 1] = d + 1; q[tail++] = i + 1 }
            if (y > 0 && id[i - w] == c && dist[i - w] < 0) { dist[i - w] = d + 1; q[tail++] = i - w }
            if (y < h - 1 && id[i + w] == c && dist[i + w] < 0) { dist[i + w] = d + 1; q[tail++] = i + w }
        }
        val strokes = Array(k) { ArrayList<List<PointF>>() }
        val seeds = Array(k) { ArrayList<PointF>() }
        // إطار سميك مانع للتسرب: حلقات متداخلة على أعماق 0 و gap و 2*gap داخل كل منطقة
        // (تُستعمل الحلقة الأعمق فقط إن بقي داخل المنطقة فراغ كافٍ للتعبئة)
        val g = Math.max(1, gap)
        val lastLevel = IntArray(cn)
        for (c in 0 until cn) {
            var m = 0
            if (best[c] > g + g) m = g
            if (best[c] > 2 * g + g) m = 2 * g
            lastLevel[c] = m
            if (best[c] > m + g && seedPix[c] >= 0) {
                val p = seedPix[c]
                seeds[cp.label[c]].add(PointF(p % w + 0.5f, p / w + 0.5f))
            }
        }
        for (lv in intArrayOf(0, g, 2 * g)) {
            val mask = BooleanArray(n)
            var any = false
            for (i in 0 until n) {
                val c = id[i]
                if (c < 0 || dist[i] != lv || lv > lastLevel[c]) continue
                mask[i] = true
                any = true
            }
            if (!any) continue
            for (cs in traceLoops(mask, id, w, h)) strokes[cp.label[cs.comp]].add(cs.pts)
        }
        return FillPlan(strokes, seeds)
    }

    private class CStroke(val comp: Int, val pts: List<PointF>)

    // تتبّع حلقات الحدود لكل منطقة على حدة وإغلاقها
    private fun traceLoops(bd: BooleanArray, cid: IntArray, w: Int, h: Int): List<CStroke> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<CStroke>()
        val step = 2
        for (s in bd.indices) {
            if (!bd[s] || visited[s]) continue
            val comp = cid[s]
            val pts = ArrayList<Int>()
            var cur = s
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (bd[ni] && !visited[ni] && cid[ni] == comp) { next = ni; break }
                }
                if (next < 0) {
                    var bdist = Int.MAX_VALUE
                    for (dy in -2..2) for (dx in -2..2) {
                        val nx = cx + dx
                        val ny = cy + dy
                        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                        val ni = ny * w + nx
                        if (bd[ni] && !visited[ni] && cid[ni] == comp) {
                            val dd = dx * dx + dy * dy
                            if (dd < bdist) { bdist = dd; next = ni }
                        }
                    }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < 8) continue
            val res = ArrayList<PointF>()
            var j = 0
            while (j < pts.size) {
                res.add(PointF(pts[j] % w + 0.5f, pts[j] / w + 0.5f))
                j += step
            }
            val l = pts[pts.size - 1]
            res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            // إغلاق الحلقة
            val f = pts[0]
            val dxl = (l % w) - (f % w)
            val dyl = (l / w) - (f / w)
            if (dxl * dxl + dyl * dyl <= 16) res.add(PointF(f % w + 0.5f, f / w + 0.5f))
            if (res.size >= 3) out.add(CStroke(comp, res))
        }
        return out
    }

    // ---------- الخلفية: لون الحافة المتصل بالحدود ----------
    private fun background(rr: IntArray, gg: IntArray, bb: IntArray, w: Int, h: Int): BooleanArray {
        val n = w * h
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var cnt = 0L
        fun add(i: Int) { sr += rr[i]; sg += gg[i]; sb += bb[i]; cnt++ }
        for (x in 0 until w) { add(x); add((h - 1) * w + x) }
        for (y in 0 until h) { add(y * w); add(y * w + w - 1) }
        val mr = (sr / cnt).toInt()
        val mg = (sg / cnt).toInt()
        val mb = (sb / cnt).toInt()
        fun isBg(i: Int) = Math.abs(rr[i] - mr) + Math.abs(gg[i] - mg) + Math.abs(bb[i] - mb) < 45

        val bg = BooleanArray(n)
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        fun push(i: Int) {
            if (!bg[i] && isBg(i)) { bg[i] = true; queue[tail++] = i }
        }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        return bg
    }

    // ---------- تقليل الألوان (k-means) ----------
    private class Quant(val labels: IntArray, val centers: IntArray)

    private fun quantize(rr: IntArray, gg: IntArray, bb: IntArray, valid: BooleanArray, k: Int): Quant {
        val n = rr.size
        var count = 0
        for (i in 0 until n) if (valid[i]) count++
        val labels = IntArray(n) { -1 }
        if (count == 0) return Quant(labels, IntArray(0))

        val stepS = Math.max(1, count / 30000)
        val cap = count / stepS + 2
        val sr = IntArray(cap)
        val sg = IntArray(cap)
        val sb = IntArray(cap)
        var m = 0
        var c = 0
        for (i in 0 until n) {
            if (!valid[i]) continue
            if (c % stepS == 0) { sr[m] = rr[i]; sg[m] = gg[i]; sb[m] = bb[i]; m++ }
            c++
        }
        val kk = Math.min(k, m)
        val cr = IntArray(kk)
        val cg = IntArray(kk)
        val cb = IntArray(kk)
        cr[0] = sr[0]; cg[0] = sg[0]; cb[0] = sb[0]
        val minD = IntArray(m) { Int.MAX_VALUE }
        for (ci in 1 until kk) {
            var best = 0
            var bd = -1
            for (s in 0 until m) {
                val dr = sr[s] - cr[ci - 1]
                val dg = sg[s] - cg[ci - 1]
                val db = sb[s] - cb[ci - 1]
                val d = dr * dr + dg * dg + db * db
                if (d < minD[s]) minD[s] = d
                if (minD[s] > bd) { bd = minD[s]; best = s }
            }
            cr[ci] = sr[best]; cg[ci] = sg[best]; cb[ci] = sb[best]
        }

        val sumR = IntArray(kk)
        val sumG = IntArray(kk)
        val sumB = IntArray(kk)
        val cnt = IntArray(kk)
        for (iter in 0 until 8) {
            java.util.Arrays.fill(sumR, 0)
            java.util.Arrays.fill(sumG, 0)
            java.util.Arrays.fill(sumB, 0)
            java.util.Arrays.fill(cnt, 0)
            for (s in 0 until m) {
                var bi = 0
                var bd = Int.MAX_VALUE
                for (ci in 0 until kk) {
                    val dr = sr[s] - cr[ci]
                    val dg = sg[s] - cg[ci]
                    val db = sb[s] - cb[ci]
                    val d = dr * dr + dg * dg + db * db
                    if (d < bd) { bd = d; bi = ci }
                }
                sumR[bi] += sr[s]; sumG[bi] += sg[s]; sumB[bi] += sb[s]; cnt[bi]++
            }
            for (ci in 0 until kk) {
                if (cnt[ci] > 0) {
                    cr[ci] = sumR[ci] / cnt[ci]
                    cg[ci] = sumG[ci] / cnt[ci]
                    cb[ci] = sumB[ci] / cnt[ci]
                }
            }
        }

        val lr = LongArray(kk)
        val lg = LongArray(kk)
        val lbb = LongArray(kk)
        val lc = LongArray(kk)
        for (i in 0 until n) {
            if (!valid[i]) continue
            var bi = 0
            var bd = Int.MAX_VALUE
            for (ci in 0 until kk) {
                val dr = rr[i] - cr[ci]
                val dg = gg[i] - cg[ci]
                val db = bb[i] - cb[ci]
                val d = dr * dr + dg * dg + db * db
                if (d < bd) { bd = d; bi = ci }
            }
            labels[i] = bi
            lr[bi] += rr[i].toLong(); lg[bi] += gg[i].toLong(); lbb[bi] += bb[i].toLong(); lc[bi]++
        }
        val centers = IntArray(kk)
        for (ci in 0 until kk) {
            centers[ci] = if (lc[ci] > 0)
                Color.rgb((lr[ci] / lc[ci]).toInt(), (lg[ci] / lc[ci]).toInt(), (lbb[ci] / lc[ci]).toInt())
            else Color.rgb(cr[ci], cg[ci], cb[ci])
        }
        return Quant(labels, centers)
    }

    // دمج الألوان المتقاربة جداً حتى لا تتكرر درجات متشابهة
    private fun mergeClose(q: Quant, n: Int, thr: Int): Quant {
        val k = q.centers.size
        if (k <= 1) return q
        val area = IntArray(k)
        for (i in 0 until n) if (q.labels[i] >= 0) area[q.labels[i]]++
        val cr = IntArray(k) { Color.red(q.centers[it]) }
        val cg = IntArray(k) { Color.green(q.centers[it]) }
        val cb = IntArray(k) { Color.blue(q.centers[it]) }
        val parent = IntArray(k) { it }
        fun find(x: Int): Int {
            var a = x
            while (parent[a] != a) a = parent[a]
            return a
        }
        while (true) {
            var bi = -1
            var bj = -1
            var bd = Int.MAX_VALUE
            for (i in 0 until k) {
                if (parent[i] != i) continue
                for (j in i + 1 until k) {
                    if (parent[j] != j) continue
                    val dr = cr[i] - cr[j]
                    val dg = cg[i] - cg[j]
                    val db = cb[i] - cb[j]
                    val d = dr * dr + dg * dg + db * db
                    if (d < bd) { bd = d; bi = i; bj = j }
                }
            }
            if (bi < 0 || bd > thr * thr) break
            val big = if (area[bi] >= area[bj]) bi else bj
            val small = if (big == bi) bj else bi
            val tot = area[big] + area[small]
            if (tot > 0) {
                cr[big] = ((cr[big].toLong() * area[big] + cr[small].toLong() * area[small]) / tot).toInt()
                cg[big] = ((cg[big].toLong() * area[big] + cg[small].toLong() * area[small]) / tot).toInt()
                cb[big] = ((cb[big].toLong() * area[big] + cb[small].toLong() * area[small]) / tot).toInt()
            }
            area[big] = tot
            area[small] = 0
            parent[small] = big
        }
        val newIdx = IntArray(k) { -1 }
        var m = 0
        for (i in 0 until k) if (parent[i] == i) newIdx[i] = m++
        val centers = IntArray(m)
        for (i in 0 until k) if (parent[i] == i) centers[newIdx[i]] = Color.rgb(cr[i], cg[i], cb[i])
        val labels = IntArray(n) { -1 }
        for (i in 0 until n) {
            val l = q.labels[i]
            if (l >= 0) labels[i] = newIdx[find(l)]
        }
        return Quant(labels, centers)
    }

    // إزالة البقع الصغيرة: اللون الأكثر تكراراً بين الجيران
    private fun smooth(labels: IntArray, w: Int, h: Int, k: Int): IntArray {
        val out = labels.copyOf()
        val cnt = IntArray(k)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val cur = labels[i]
                if (cur < 0) continue
                java.util.Arrays.fill(cnt, 0)
                for (dy in -1..1) for (dx in -1..1) {
                    val l = labels[i + dy * w + dx]
                    if (l >= 0) cnt[l]++
                }
                var best = cur
                var bc = cnt[cur]
                for (l in 0 until k) if (cnt[l] > bc) { bc = cnt[l]; best = l }
                out[i] = best
            }
        }
        return out
    }

    // توسيع الألوان تحت خطوط الحدود حتى لا تبقى فجوات
    private fun spread(labels: IntArray, bg: BooleanArray, w: Int, h: Int) {
        val n = w * h
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        for (i in 0 until n) if (labels[i] >= 0) queue[tail++] = i
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            val l = labels[i]
            if (x > 0 && labels[i - 1] < 0 && !bg[i - 1]) { labels[i - 1] = l; queue[tail++] = i - 1 }
            if (x < w - 1 && labels[i + 1] < 0 && !bg[i + 1]) { labels[i + 1] = l; queue[tail++] = i + 1 }
            if (y > 0 && labels[i - w] < 0 && !bg[i - w]) { labels[i - w] = l; queue[tail++] = i - w }
            if (y < h - 1 && labels[i + w] < 0 && !bg[i + w]) { labels[i + w] = l; queue[tail++] = i + w }
        }
    }

    // نقطة داخل منطقة اللون (أطول مقطع أفقي له دعم عمودي) لأخذ اللون بالقطّارة
    private fun pickPoint(labels: IntArray, lab: Int, w: Int, h: Int): PointF {
        var bestLen = -1
        var bx = -1
        var by = -1
        var y = 4
        while (y < h - 4) {
            var x = 0
            while (x < w) {
                if (labels[y * w + x] == lab) {
                    val s = x
                    while (x < w && labels[y * w + x] == lab) x++
                    val len = x - s
                    if (len > bestLen) {
                        val mx = (s + x - 1) / 2
                        if (labels[(y - 4) * w + mx] == lab && labels[(y + 4) * w + mx] == lab) {
                            bestLen = len; bx = mx; by = y
                        }
                    }
                } else {
                    x++
                }
            }
            y += 2
        }
        if (bx < 0) {
            for (i in labels.indices) if (labels[i] == lab) { bx = i % w; by = i / w; break }
        }
        return PointF(bx + 0.5f, by + 0.5f)
    }

    // ---------- تلوين متعرّج (serpentine) لمنطقة لون واحد ----------
    private fun scribble(labels: IntArray, lab: Int, w: Int, h: Int, gap: Int): List<List<PointF>> {
        val ys = ArrayList<Int>()
        val rows = ArrayList<ArrayList<IntArray>>()
        var y = gap / 2 + 1
        while (y < h - 1) {
            val runs = ArrayList<IntArray>()
            var x = 0
            while (x < w) {
                if (labels[y * w + x] == lab) {
                    val s = x
                    while (x < w && labels[y * w + x] == lab) x++
                    if (x - s >= 3) runs.add(intArrayOf(Math.max(0, s - 1), Math.min(w - 1, x), 0))
                } else {
                    x++
                }
            }
            ys.add(y)
            rows.add(runs)
            y += gap
        }

        val out = ArrayList<List<PointF>>()
        val maxJump = 2 * gap + 2
        for (ri in rows.indices) {
            for (run in rows[ri]) {
                if (run[2] == 1) continue
                run[2] = 1
                val pts = ArrayList<PointF>()
                var lr = true
                pts.add(PointF(run[0] + 0.5f, ys[ri] + 0.5f))
                pts.add(PointF(run[1] + 0.5f, ys[ri] + 0.5f))
                var cur = run
                var r = ri
                while (r + 1 < rows.size && pts.size < 300) {
                    val endX = if (lr) cur[1] else cur[0]
                    var found: IntArray? = null
                    var startAtLeft = true
                    for (cand in rows[r + 1]) {
                        if (cand[2] == 1) continue
                        if (cand[0] > cur[1] || cand[1] < cur[0]) continue
                        val dl = Math.abs(endX - cand[0])
                        val dr = Math.abs(endX - cand[1])
                        val sx = if (dl <= dr) cand[0] else cand[1]
                        if (Math.abs(endX - sx) <= maxJump) {
                            found = cand
                            startAtLeft = dl <= dr
                            break
                        }
                    }
                    if (found == null) break
                    found[2] = 1
                    r++
                    val yy = ys[r] + 0.5f
                    if (startAtLeft) {
                        pts.add(PointF(found[0] + 0.5f, yy))
                        pts.add(PointF(found[1] + 0.5f, yy))
                        lr = true
                    } else {
                        pts.add(PointF(found[1] + 0.5f, yy))
                        pts.add(PointF(found[0] + 0.5f, yy))
                        lr = false
                    }
                    cur = found
                }
                out.add(pts)
            }
        }
        return out
    }

    // تعبئة المساحات الداكنة في وضع الخطوط فقط
    private fun hatch(region: BooleanArray, w: Int, h: Int, gap: Int): List<List<PointF>> {
        val out = ArrayList<List<PointF>>()
        var rowIdx = 0
        var y = gap / 2 + 1
        while (y < h - 1) {
            val runs = ArrayList<IntArray>()
            var x = 0
            while (x < w) {
                if (region[y * w + x]) {
                    val s = x
                    while (x < w && region[y * w + x]) x++
                    if (x - s >= 3) runs.add(intArrayOf(s, x - 1))
                } else {
                    x++
                }
            }
            if (rowIdx % 2 == 1) runs.reverse()
            for (r in runs) {
                val a = PointF(r[0] + 0.5f, y + 0.5f)
                val b = PointF(r[1] + 0.5f, y + 0.5f)
                out.add(if (rowIdx % 2 == 0) listOf(a, b) else listOf(b, a))
            }
            rowIdx++
            y += gap
        }
        return out
    }

    // ---------- Zhang-Suen ----------
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        val del = IntArray(w * h)
        var changed = true
        while (changed) {
            changed = false
            for (step in 0..1) {
                var cnt = 0
                for (y in 1 until h - 1) {
                    for (x in 1 until w - 1) {
                        val i = y * w + x
                        if (!img[i]) continue
                        val p2 = img[i - w]
                        val p3 = img[i - w + 1]
                        val p4 = img[i + 1]
                        val p5 = img[i + w + 1]
                        val p6 = img[i + w]
                        val p7 = img[i + w - 1]
                        val p8 = img[i - 1]
                        val p9 = img[i - w - 1]
                        var nn = 0
                        if (p2) nn++
                        if (p3) nn++
                        if (p4) nn++
                        if (p5) nn++
                        if (p6) nn++
                        if (p7) nn++
                        if (p8) nn++
                        if (p9) nn++
                        if (nn < 2 || nn > 6) continue
                        var a = 0
                        if (!p2 && p3) a++
                        if (!p3 && p4) a++
                        if (!p4 && p5) a++
                        if (!p5 && p6) a++
                        if (!p6 && p7) a++
                        if (!p7 && p8) a++
                        if (!p8 && p9) a++
                        if (!p9 && p2) a++
                        if (a != 1) continue
                        if (step == 0) {
                            if (p2 && p4 && p6) continue
                            if (p4 && p6 && p8) continue
                        } else {
                            if (p2 && p4 && p8) continue
                            if (p2 && p6 && p8) continue
                        }
                        del[cnt++] = i
                    }
                }
                if (cnt > 0) {
                    changed = true
                    for (q in 0 until cnt) img[del[q]] = false
                }
            }
        }
    }

    private val dxs = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
    private val dys = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)

    private fun trace(sk: BooleanArray, w: Int, h: Int): List<List<PointF>> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<List<PointF>>()
        val step = 2
        val minPts = 12

        fun neighborCount(i: Int): Int {
            val x = i % w
            val y = i / w
            var c = 0
            for (k in 0 until 8) {
                val nx = x + dxs[k]
                val ny = y + dys[k]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                if (sk[ny * w + nx]) c++
            }
            return c
        }

        fun walk(start: Int) {
            val pts = ArrayList<Int>()
            var cur = start
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (sk[ni] && !visited[ni]) { next = ni; break }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < minPts) return
            val res = ArrayList<PointF>()
            var k = 0
            while (k < pts.size) {
                res.add(PointF(pts[k] % w + 0.5f, pts[k] / w + 0.5f))
                k += step
            }
            if ((pts.size - 1) % step != 0) {
                val l = pts[pts.size - 1]
                res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            }
            if (res.size >= 2) out.add(res)
        }

        for (i in sk.indices) if (sk[i] && !visited[i] && neighborCount(i) <= 1) walk(i)
        for (i in sk.indices) if (sk[i] && !visited[i]) walk(i)
        return out
    }
}
